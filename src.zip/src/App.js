import { useState } from 'react';
import React from 'react';


function App() {
  const [mynumber1,setNumber1] = useState(0);
  const [mynumber2,setNumber2] = useState(1);
  const [mynumber3,setNumber3] = useState(2);
  const [round1,setRound] = useState(0);
  const [trial1,setTrial] = useState(0);
  const [res1,setres1] = useState([]);
  
  const [result,setresult] = useState('...Try and Win...');
  const ref = React.useRef(null);

  // const myInterval = setInterval(()=>{
    // setcounter(counter++);
    // console.log(counter);
    
    const btnClicked=(e)=>{
      if(trial1==2){
        setTrial(0);
        e.target.disabled=true;
        ref.current.disabled=false;
      }else{
        setTrial(trial1+1);
      }
      for(let i = 0;i<3;i++){
        setTimeout(
          ()=>{
            
            setRound(i+1);
            let updated1 = Math.floor(Math.random() * (3) );
            let updated2 = Math.floor(Math.random() * (3) );
            let updated3 = Math.floor(Math.random() * (3) );
            setNumber1(updated1);
            setNumber2(updated2);
            setNumber3(updated3);
            if(i==2){
              if(updated1==updated2 && updated2==updated3){
                res1.push(10);
                setres1(res1);
                setresult('🏆 Congratulations!!! You Win 🎁');
              }else{
                res1.push(0);
                setres1(res1);
                setresult('Better luck next time 😏');
              }
              console.log(trial1);
            }
          }
          
      ,1000*i);
      }
    }
    const arr = ['😄',' 👍', '💯'];

    const newGame=()=>{
      console.log('newGame');
      setNumber1(0);
      setNumber2(1);
      setNumber3(2);
      setRound(0);
      setTrial(0);
      setres1([]);
      setresult('...Try and Win...');
    }

  return (
    <>
      <div style={{fontSize:'35px',textAlign:'center'}}>
        <button onClick={btnClicked}>Click for Trial {trial1+1}</button>
        <button onClick={newGame} ref={ref} disabled>New Game</button><hr/>
        Round{round1}:
        ||{arr[mynumber1]}||
        ||{arr[mynumber2]}||
        ||{arr[mynumber3]}||<hr/>
        {result}<hr/>
        <ol>{trial1}
          <li>Trial1 result:{res1[0]}</li>
          <li>Trial2 result:{res1[1]}</li>
          <li>Trial3 result:{res1[2]}</li>
        </ol>
      </div>
    </>
  );
}

export default App;


